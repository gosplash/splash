# Time to Correct Software · Pilot 001

In a small feasibility study, six fresh Codex sessions independently repaired the same invoice-rounding bug using matched Go and Splash starters. All six returned correct solutions. The results validate this authoring and grading workflow for a single task and leave the comparative effect of language choice unestablished.

| Language | Accepted | First accepted snapshots | Median |
| --- | ---: | --- | ---: |
| Go | 3/3 | 13.334 s, 15.007 s, 15.011 s | 15.007 s |
| Splash | 3/3 | 13.840 s, 13.952 s, 14.905 s | 13.952 s |

Each solution passed 40 fresh sealed cases and all nine checked-in fixture cases. Correct reference implementations passed both sets. The truncating starters passed the public checks and failed the independent grading at the intended half-cent boundary. The Splash arm used its Go-backed native path. Every agent chose the same arithmetic correction and needed one edit and one public verification.

## Protocol

- The paired arms used the same ticket and public case inputs from Splash revision `e15ec6de9706c5c084d577c43bace12361566800`. A short reference supplied each language's core syntax. Each session used `gpt-6.2-sol` at medium reasoning effort and Codex CLI 0.170.0.
- The trial tools allowed reading supplied files, replacing the single editable source file, and running the visible checks. Fresh sealed cases and expected results remained outside the workspace. Grading ran after all agent sessions. Candidate code ran in nonroot, network-disabled Linux ARM64 containers with bounded resources. The host was an Apple M5 with Docker 29.4.3 and Go 1.26.3 in the container.
- The elapsed clock started before Codex launch. The runner captured a starter, scheduled observations at 15, 30, 60, 120, and 180 seconds where reached, and a final snapshot. The first accepted observation is an upper bound on when that observed solution was written. Independent grading time is outside this elapsed interval.
- An initial six-session batch produced no candidate edits because the trial tools required approval. Both arms were rerun in fresh sessions with the bounded tools explicitly enabled. The infrastructure attempt is retained separately.

## Token accounting

| Language | Input | Cached input | Derived uncached input | Output | Reasoning-output counter |
| --- | ---: | ---: | ---: | ---: | ---: |
| Go | 241,367 | 216,192 | 25,175 | 985 | 52 |
| Splash | 225,881 | 196,608 | 29,273 | 963 | 21 |

These totals cover the three completed trials in each arm. Derived uncached input assumes cached input is a subset of reported input. The raw files retain the initial infrastructure attempt separately so it can be included in expenditure accounting. Session totals include repeated prompt context and harness overhead. Monetary inference and execution costs were unavailable.

The starter is public, so model exposure is uncontrolled. The edit was small, every agent succeeded, and the acceptance times overlap. The study also used restricted workspace tools, three concurrent replicates per language, and coarse first-observation timing. It provides evidence that the tested model can repair this Splash program with a short reference. It provides little evidence about comparative authoring cost, backend effects, or semantic context needs in larger repositories.

## Reproduction

The [manifest](manifest.json) pins the measured inputs and the [results](results.json) give each trial's checkpoint, verification, and usage records. The [initial infrastructure attempt](infrastructure-attempt.json) is retained. The exact original sealed inputs are held separately. The included public runner uses fresh generated values for all sealed case families and records their digest.

Copy this bundle into a clean directory. From a Splash checkout, export `cmd/`, `internal/`, `go.mod`, and `benchmarks/ttcs/invoice/` from the pinned revision. Place the invoice directory in the bundle as `fixture/` and the remaining exports at the bundle root. Then run:

```sh
docker build --platform linux/arm64 -t splash-ttcs-invoice:e15ec6d .
python3 -B pilot.py
```

This requires Docker, Python 3.9 or later, and authenticated Codex CLI access to the model. Run in a fresh directory for each batch. The image configuration and original image identity are recorded in the manifest.
