import concurrent.futures as futures
from fractions import Fraction
from hashlib import sha256
import json
import os
from pathlib import Path
import platform
import random
import selectors
import shutil
import stat
import statistics
import subprocess
import sys
import tempfile
import time
import uuid

ROOT = Path(__file__).resolve().parent
FIXTURE = ROOT / "fixture"
sys.path.insert(0, str(FIXTURE))
import grade

IMAGE = "splash-ttcs-invoice:e15ec6d"
REVISION = "e15ec6de9706c5c084d577c43bace12361566800"
MODEL = "gpt-6.2-sol"
EFFORT = "medium"
DEADLINE = 180
CHECKPOINTS = (15, 30, 60, 120, DEADLINE)
LIMIT = 16_384
REPLICATES = 3
ARMS = ("go", "splash")
PUBLIC = FIXTURE / "task/public-cases.json"


def write_json(path, data):
    path.write_text(json.dumps(data, indent=2) + "\n")


def digest(data):
    return sha256(data).hexdigest()


def invoice(lane):
    return f"invoice.{lane}"


def execute(lane, source, cases):
    with tempfile.TemporaryDirectory(dir=ROOT, prefix="stage-") as tmp:
        staging = Path(tmp)
        staging.chmod(0o755)
        (staging / invoice(lane)).write_bytes(source)
        (staging / "probe.go" if lane == "go" else staging / "probe.splash").write_text(
            grade.go_driver(cases) if lane == "go" else grade.splash_driver(cases)
        )
        for item in staging.iterdir():
            item.chmod(0o644)
        script = (
            "go build -p=2 -o /tmp/probe invoice.go probe.go"
            if lane == "go" else
            "splash check probe.splash >&2 && splash build probe.splash -o /tmp/probe >&2"
        )
        script = (
            "cp -R /opt/gocache /tmp/gocache; "
            "export GOCACHE=/tmp/gocache; "
            + script
            + "; timeout -s KILL 4 /tmp/probe"
        )
        name = "ttcs-invoice-" + uuid.uuid4().hex[:14]
        cmd = [
            "docker", "run", "--rm", "--name", name, "--network", "none", "--read-only",
            "--tmpfs", "/tmp:rw,exec,nosuid,nodev,mode=1777,size=384m",
            "--cap-drop", "ALL", "--security-opt", "no-new-privileges", "--pids-limit", "80",
            "--memory", "640m", "--cpus", "1", "--user", "65532:65532", "--ulimit", "core=0",
            "--mount", f"type=bind,source={staging},target=/candidate,readonly",
            "--workdir", "/candidate", "--env", "HOME=/tmp", "--env", "TMPDIR=/tmp",
            IMAGE, "/bin/sh", "-euc", script,
        ]
        process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        timeout = time.monotonic() + 30
        gathered = {"stdout": bytearray(), "stderr": bytearray()}
        abort = None
        try:
            with selectors.DefaultSelector() as io:
                for stream in gathered:
                    io.register(getattr(process, stream), selectors.EVENT_READ, stream)
                while io.get_map():
                    remaining = timeout - time.monotonic()
                    if remaining <= 0:
                        abort = "verification timeout"
                        break
                    for key, _ in io.select(remaining):
                        chunk = os.read(key.fd, 8192)
                        if not chunk:
                            io.unregister(key.fileobj)
                            continue
                        buffer = gathered[key.data]
                        buffer.extend(chunk)
                        if len(buffer) > 65_536:
                            abort = "verification output limit exceeded"
                            break
                    if abort:
                        break
            if not abort:
                process.wait(timeout=max(0.1, timeout - time.monotonic()))
        except subprocess.TimeoutExpired:
            abort = "verification timeout"
        finally:
            if abort:
                subprocess.run(["docker", "rm", "-f", name], capture_output=True, timeout=10)
                process.kill()
                process.wait(timeout=5)
        out, stderr = (bytes(gathered[s]).decode("utf-8", "replace") for s in ("stdout", "stderr"))
        if abort:
            return {"accepted": False, "stage": "timeout_or_limit", "message": abort}
        if process.returncode:
            return {
                "accepted": False, "stage": "build_or_execution",
                "message": (stderr or out).strip()[:4500], "exit": process.returncode,
            }
        mismatch = grade.output_mismatch(out.splitlines(), cases)
        return {
            "accepted": mismatch is None, "stage": "functional",
            "message": mismatch or f"accepted {len(cases)} cases",
        }


def case(label, inputs):
    qty, cents, percent = inputs
    subtotal = qty * cents
    exact = Fraction(subtotal * percent, 100)
    whole, remainder = divmod(exact.numerator, exact.denominator)
    rounded = whole + (2 * remainder >= exact.denominator)
    return {"name": label, "inputs": inputs, "expected": [subtotal, rounded, subtotal - rounded]}


def seal():
    private = ROOT / "grader"
    private.mkdir(exist_ok=True)
    sealed = private / "cases.json"
    if sealed.exists():
        return grade.read_cases(sealed)
    # Fixed behavior families plus fresh pseudorandom inputs. Commit the exact file hash before dispatch.
    rng = random.Random(int.from_bytes(os.urandom(16), "big"))
    tuples = []
    for remainder in (1, 49, 50, 51, 99):
        qty = rng.randrange(1, 100) * 100 + 1
        cents = rng.randrange(1, 20) * 100 + 1
        tuples.append((f"remainder {remainder}/100", (qty, cents, remainder)))
    # Public reproduction generates fresh inputs in every case family.
    # The original run's sealed cases are retained separately.
    tuples.extend([
        ("aggregation before rounding", (rng.choice((2, 6, 10)), rng.choice((3, 7, 11)), 25)),
        ("quantity bound partial discount", (10_000, rng.randrange(1, 2_001), rng.randrange(1, 100))),
        ("price bound exact discount", (rng.randrange(1, 10_001), 2_000, rng.randrange(101))),
        ("max quantity", (10_000, rng.randrange(2_001), 100)),
        ("zero units", (0, rng.randrange(2_001), rng.randrange(1, 101))),
        ("zero unit price", (rng.randrange(1, 10_001), 0, rng.randrange(1, 101))),
        ("zero discount", (rng.randrange(1, 10_001), rng.randrange(1, 2_001), 0)),
        ("full discount", (rng.randrange(1, 10_001), rng.randrange(1, 2_001), 100)),
    ])
    tuples.extend(
        (f"sample {i+1}", (rng.randrange(10_001), rng.randrange(2001), rng.randrange(101)))
        for i in range(27)
    )
    result = [case(label, inputs) for label, inputs in tuples]
    write_json(sealed, result)
    sealed.chmod(0o600)
    return result


def controls(sealed):
    public = grade.read_cases(PUBLIC)
    checked_in = grade.read_cases(FIXTURE / "oracle/cases.json")
    cache = {}
    def control(lane, path, tag, cases, accepted):
        result = execute(lane, path.read_bytes(), cases)
        assert result["stage"] == "functional" and result["accepted"] == accepted, (lane, tag, result)
        if tag == "starter_sealed":
            assert "50/100" in result["message"], (lane, result)
        if tag == "starter_checked_in":
            assert "half-cent" in result["message"], (lane, result)
        return lane, tag, result
    with futures.ThreadPoolExecutor(max_workers=4) as pool:
        jobs = []
        for lane in ARMS:
            reference = FIXTURE / "oracle/testdata" / lane / invoice(lane)
            starter = FIXTURE / "task/testdata" / lane / invoice(lane)
            for path, tag, cases, accepts in (
                (reference, "reference_sealed", sealed, True),
                (starter, "starter_sealed", sealed, False),
                (starter, "starter_public", public, True),
                (reference, "reference_checked_in", checked_in, True),
                (starter, "starter_checked_in", checked_in, False),
            ):
                jobs.append(pool.submit(control, lane, path, tag, cases, accepts))
        for job in futures.as_completed(jobs):
            lane, tag, result = job.result()
            cache.setdefault(lane, {})[tag] = result
    write_json(ROOT / "controls.json", cache)
    print("Control checks passed in both arms", flush=True)


def read_source(path):
    st = path.lstat()
    if not stat.S_ISREG(st.st_mode) or st.st_nlink != 1 or st.st_size > LIMIT:
        raise ValueError("source must be a regular single file within byte limit")
    return path.read_bytes()


def mcp(lane, workspace):
    source = workspace / invoice(lane)
    read_paths = {
        invoice(lane): source, "TASK.md": workspace / "TASK.md",
        "REFERENCE.md": workspace / "REFERENCE.md", "public-cases.json": workspace / "public-cases.json",
    }
    visible = grade.read_cases(read_paths["public-cases.json"])
    tool_list = [
        {
            "name": name, "description": description,
            "inputSchema": {"type": "object", "properties": props, "required": list(props), "additionalProperties": False},
        }
        for name, description, props in [
            ("read_text", "Read a task file. Available files are TASK.md, REFERENCE.md, public-cases.json, and your invoice file.", {"file": {"type": "string"}}),
            ("write_invoice", "Replace the editable invoice source file with this full UTF-8 source.", {"source": {"type": "string"}}),
            ("verify_public", "Compile and execute the current invoice file on the two visible public cases.", {}),
        ]
    ]
    for line in sys.stdin:
        request = json.loads(line)
        if "id" not in request:
            continue
        result = None
        method = request.get("method")
        if method == "initialize":
            result = {
                "protocolVersion": "2024-11-05",
                "capabilities": {"tools": {}},
                "serverInfo": {"name": "ttcs-invoice-workspace", "version": "1"},
            }
        elif method == "tools/list":
            result = {"tools": tool_list}
        elif method == "tools/call":
            name = request["params"]["name"]
            args = request["params"].get("arguments", {})
            is_error = False
            try:
                if name == "read_text":
                    value = read_source(read_paths[args["file"]]).decode("utf-8")
                elif name == "write_invoice":
                    data = args["source"].encode()
                    if not data or len(data) > LIMIT:
                        raise ValueError("invoice source length outside supported range")
                    pending = workspace / ".invoice.tmp"
                    pending.write_bytes(data)
                    pending.replace(source)
                    value = "invoice source saved"
                elif name == "verify_public":
                    response = execute(lane, read_source(source), visible)
                    value = response["message"]
                    is_error = not response["accepted"]
                else:
                    raise ValueError("unknown tool")
            except (KeyError, ValueError, OSError) as error:
                value = str(error)
                is_error = True
            result = {"content": [{"type": "text", "text": value}], "isError": is_error}
        if result is None:
            response = {"jsonrpc": "2.0", "id": request["id"], "error": {"code": -32601, "message": "unknown method"}}
        else:
            response = {"jsonrpc": "2.0", "id": request["id"], "result": result}
        print(json.dumps(response), flush=True)


def run_trial(entry, prompt):
    trial_id, lane = entry["id"], entry["lane"]
    run_dir = ROOT / "trials" / trial_id
    workspace = run_dir / "workspace"
    workspace.mkdir(parents=True)
    source = workspace / invoice(lane)
    shutil.copyfile(FIXTURE / "task/testdata" / lane / source.name, source)
    shutil.copyfile(FIXTURE / "task/TASK.md", workspace / "TASK.md")
    shutil.copyfile(PUBLIC, workspace / "public-cases.json")
    shutil.copyfile(ROOT / f"{lane}-reference.md", workspace / "REFERENCE.md")
    snapshots = run_dir / "snapshots"
    snapshots.mkdir()
    start = time.monotonic()
    observations = []
    def capture(label, scheduled=None):
        data = read_source(source)
        key = digest(data)
        target = snapshots / key
        if not target.exists():
            target.write_bytes(data)
            target.chmod(0o400)
        observations.append({"label": label, "scheduled_s": scheduled, "observed_s": time.monotonic() - start, "sha256": key})
    command = [
        "codex", "exec", "--json", "--ephemeral", "--ignore-user-config", "--ignore-rules",
        "--skip-git-repo-check", "--color", "never", "--model", MODEL, "-s", "read-only",
        "-c", f'model_reasoning_effort="{EFFORT}"', "-c", 'approval_policy="never"',
        "-c", 'web_search="disabled"', "--disable", "shell_tool", "--disable", "shell_snapshot",
        "--disable", "apps", "--disable", "hooks", "--disable", "multi_agent", "--disable", "multi_agent_v2",
        "--enable", "skip_host_skill_discovery",
        "-c", f'mcp_servers.workspace.command={json.dumps(sys.executable)}',
        "-c", f'mcp_servers.workspace.args={json.dumps(["-B", str(Path(__file__).resolve()), "tools", lane, str(workspace)])}',
        "-c", "mcp_servers.workspace.tool_timeout_sec=40",
        "-c", 'mcp_servers.workspace.tools.read_text.approval_mode="approve"',
        "-c", 'mcp_servers.workspace.tools.write_invoice.approval_mode="approve"',
        "-c", 'mcp_servers.workspace.tools.verify_public.approval_mode="approve"', 
        "-C", str(workspace), prompt.replace("{INVOICE}", source.name),
    ]
    capture("starter", 0)
    print(f"Started {trial_id}", flush=True)
    timed_out = False
    with (run_dir / "events.jsonl").open("wb") as events, (run_dir / "runner.stderr").open("wb") as stderr:
        process = subprocess.Popen(command, stdin=subprocess.DEVNULL, stdout=events, stderr=stderr)
        for mark in CHECKPOINTS:
            wait = start + mark - time.monotonic()
            try:
                process.wait(timeout=max(0, wait))
                break
            except subprocess.TimeoutExpired:
                capture("checkpoint", mark)
        if process.poll() is None:
            timed_out = True
            process.terminate()
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=5)
        capture("final")
    output = {
        **entry, "seconds": observations[-1]["observed_s"], "exit": process.returncode,
        "timeout": timed_out, "observations": observations,
    }
    write_json(run_dir / "trial.json", output)
    print(f"Finished {trial_id} ({output['seconds']:.2f} s, exit {output['exit']})", flush=True)
    return output


def seal_and_run():
    sealed = seal()
    checked_in = grade.read_cases(FIXTURE / "oracle/cases.json")
    prompt = (ROOT / "prompt.txt").read_text().strip()
    manifest = []
    seed = 20261127
    random_order = random.Random(seed)
    for pair in range(1, REPLICATES + 1):
        block = [{"id": f"{lane}-{pair}", "lane": lane, "block": pair} for lane in ARMS]
        random_order.shuffle(block)
        manifest.extend(block)
    sealed_path = ROOT / "grader/cases.json"
    pre_run = {
        "source_revision": REVISION, "model": MODEL, "reasoning_effort": EFFORT,
        "codex_version": subprocess.check_output(["codex", "--version"], text=True).strip(),
        "host": platform.platform(), "container_arch": "linux/arm64",
        "docker_server": subprocess.check_output(["docker", "version", "--format", "{{.Server.Version}}"], text=True).strip(),
        "image_id": subprocess.check_output(["docker", "image", "inspect", IMAGE, "--format", "{{.Id}}"], text=True).strip(),
        "go_version": subprocess.check_output(["docker", "run", "--rm", "--network", "none", IMAGE, "go", "version"], text=True).strip(),
        "ceiling_seconds": DEADLINE, "planned_checkpoints_seconds": CHECKPOINTS,
        "grading_case_count": len(sealed), "sealed_cases_sha256": digest(sealed_path.read_bytes()),
        "baseline_fixture_sha256": digest((FIXTURE / "oracle/cases.json").read_bytes()),
        "prompt_sha256": digest((ROOT / "prompt.txt").read_bytes()), "dispatch_seed": seed,
        "lane_launch_order": manifest,
    }
    write_json(ROOT / "manifest.json", pre_run)
    controls(sealed)
    with futures.ThreadPoolExecutor(max_workers=len(manifest)) as pool:
        jobs = [pool.submit(run_trial, trial, prompt) for trial in manifest]
        trials = [job.result() for job in jobs]
    print("Starting independent grading", flush=True)
    with futures.ThreadPoolExecutor(max_workers=4) as pool:
        jobs = {}
        for trial in trials:
            for obs in trial["observations"]:
                key = trial["lane"], obs["sha256"]
                if key not in jobs:
                    source = (ROOT / "trials" / trial["id"] / "snapshots" / obs["sha256"]).read_bytes()
                    jobs[key] = pool.submit(
                        lambda lane, source: {"sealed": execute(lane, source, sealed), "fixture": execute(lane, source, checked_in)},
                        trial["lane"], source,
                    )
        for trial in trials:
            for obs in trial["observations"]:
                outcomes = jobs[trial["lane"], obs["sha256"]].result()
                obs["accepted"] = all(item["accepted"] for item in outcomes.values())
                obs["grade"] = {name: {"accepted": result["accepted"], "stage": result["stage"]} for name, result in outcomes.items()}
            accepted = [obs for obs in trial["observations"] if obs["accepted"]]
            trial["final_accepted"] = trial["observations"][-1]["accepted"]
            trial["first_observed_accepted_s"] = accepted[0]["observed_s"] if accepted else None
            run_dir = ROOT / "trials" / trial["id"]
            events = [json.loads(line) for line in (run_dir / "events.jsonl").read_text().splitlines()]
            trial["usage"] = [e["usage"] for e in events if e.get("type") == "turn.completed" and "usage" in e]
            trial["tool_calls"] = [
                {k: e["item"].get(k) for k in ("server", "tool", "status")}
                for e in events if e.get("type") == "item.completed" and e.get("item", {}).get("type") == "mcp_tool_call"
            ]
            trial["infrastructure_tool_errors"] = [
                e["item"].get("error") for e in events
                if e.get("type") == "item.completed"
                and e.get("item", {}).get("type") == "mcp_tool_call"
                and isinstance(e["item"].get("error"), dict)
            ]
            trial["unplanned_tool_events"] = [
                e["item"].get("type") for e in events if e.get("type") == "item.completed"
                and e.get("item", {}).get("type") in {"web_search", "file_change", "command_execution", "collab_tool_call"}
            ]
            write_json(run_dir / "trial.json", trial)
    summary = {}
    for lane in ARMS:
        arm = [trial for trial in trials if trial["lane"] == lane]
        capped = [t["first_observed_accepted_s"] if t["first_observed_accepted_s"] is not None else DEADLINE for t in arm]
        summary[lane] = {
            "trials": len(arm), "final_accepted": sum(t["final_accepted"] for t in arm),
            "completed_agent_sessions": sum(t["exit"] == 0 for t in arm),
            "capped_first_observed_median_s": statistics.median(capped),
        }
    write_json(ROOT / "results.json", {"manifest": pre_run, "arms": summary, "trials": trials})
    print(json.dumps(summary, indent=2), flush=True)


if __name__ == "__main__":
    if sys.argv[1:2] == ["tools"]:
        mcp(sys.argv[2], Path(sys.argv[3]))
    elif sys.argv[1:2] == ["controls"]:
        controls(seal())
    else:
        seal_and_run()
